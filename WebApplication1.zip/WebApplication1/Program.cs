using AutoMate.ServiceHost;
using Microsoft.AspNetCore.SignalR;

namespace WebApplication1
{
    public class Program
    {

        private static IHubContext<SignalRHub>? _hubContext;
        static JobDetails jobDetails = new JobDetails()
        {
            JobId = "1",
            TargetMachine = "Desktop"
        };
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddSignalR();
            var app = builder.Build();
            app.UseDefaultFiles();
            app.UseStaticFiles();

            if (app.Environment.IsDevelopment())
            {

            }
            var webSocketOptions = new WebSocketOptions
            {
                KeepAliveInterval = TimeSpan.FromMinutes(2)
            };

            app.UseWebSockets(webSocketOptions);
            app.MapHub<SignalRHub>("/orch");
            app.MapGet("/", () => "Hello World!");

            new Thread(app.Run).Start();

            _hubContext = app.Services.GetService<IHubContext<SignalRHub>>();

            

            new Thread(SendCommands).Start();
           

             static void SendCommands()
            {

                while (true)
                {
                    Console.WriteLine("Enter your command");
                    string command = Console.ReadLine();
                    _hubContext.Clients.All.SendAsync("ReceiveMessageServer", command, jobDetails);
                }
            }
        }


    }
    class JobDetails
    {
        public string JobId { get; set; }
        public string TargetMachine {  get; set; }
        
    }

}