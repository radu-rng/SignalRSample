﻿using Microsoft.AspNetCore.SignalR;

namespace AutoMate.ServiceHost
{
    public class SignalRHub : Hub
    {
        

        public async Task ProcessMessageFromCLient(string command)
        {
            await Clients.All.SendAsync("ReceiveMessage", $"Message received from hub client: {command}");
            Console.WriteLine(command);
        }

    }
}
